#!/usr/bin/env python3
import asyncio, sys, json
from urllib.parse import urljoin
from pathlib import Path
import aiohttp, async_timeout
from tqdm.asyncio import tqdm as async_tqdm

DEFAULT_CONCURRENCY = 20
DEFAULT_DELAY = 0.02

async def check_url(session, url, timeout=10):
    try:
        async with async_timeout.timeout(timeout):
            async with session.get(url, allow_redirects=True) as resp:
                status = resp.status
                if status not in (404,400,403):
                    return {"url": url, "status": status}
    except Exception:
        return None

async def worker(queue, session, results, delay):
    while True:
        item = await queue.get()
        if item is None:
            queue.task_done()
            break
        res = await check_url(session, item)
        if res:
            results.append(res)
        await asyncio.sleep(delay)
        queue.task_done()

async def run_bruteforce(base, wordlist, concurrency=DEFAULT_CONCURRENCY, delay=DEFAULT_DELAY):
    q = asyncio.Queue()
    results = []
    for w in wordlist:
        q.put_nowait(urljoin(base, w))
        q.put_nowait(urljoin(base, w + "/"))
    async with aiohttp.ClientSession(headers={"User-Agent":"AsyncPoC/0.1"}) as session:
        workers = [asyncio.create_task(worker(q, session, results, delay)) for _ in range(concurrency)]
        for _ in range(concurrency):
            q.put_nowait(None)
        await q.join()
        for w in workers:
            w.cancel()
    return results

def main():
    if len(sys.argv) < 3:
        print("Usage: python async_dirs.py <base_url> <wordlist_file> [out.json] [--concurrency N] [--delay D]")
        sys.exit(1)
    base = sys.argv[1]
    wl = Path(sys.argv[2]).read_text(encoding='utf-8').splitlines()
    out = sys.argv[3] if len(sys.argv) > 3 else "async_results.json"
    conc = 20
    delay = 0.02
    if "--concurrency" in sys.argv:
        conc = int(sys.argv[sys.argv.index("--concurrency")+1])
    if "--delay" in sys.argv:
        delay = float(sys.argv[sys.argv.index("--delay")+1])
    results = asyncio.run(run_bruteforce(base, [l.strip() for l in wl if l.strip()], concurrency=conc, delay=delay))
    Path(out).write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(f"Saved {len(results)} results to {out}")

if __name__ == "__main__":
    main()
