#!/usr/bin/env python3
import sys, json
from jinja2 import Environment, FileSystemLoader, select_autoescape
def main():
    if len(sys.argv) < 3:
        print("Usage: python generate_report.py <input_json> <output_html>")
        return
    data = json.load(open(sys.argv[1], encoding='utf-8'))
    env = Environment(loader=FileSystemLoader("."), autoescape=select_autoescape(["html","xml"]))
    tmpl = env.get_template("report_template.html")
    rendered = tmpl.render(**data)
    open(sys.argv[2], "w", encoding='utf-8').write(rendered)
    print("Saved", sys.argv[2])
if __name__ == "__main__":
    main()
