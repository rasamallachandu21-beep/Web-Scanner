#!/usr/bin/env python3
"""
scanner.py - Simple Web Application Vulnerability Scanner (PoC)
Usage examples:
  python scanner.py "http://localhost:3000" --out reports/juice_scan.json --wordlist wordlists/common_dirs.txt
Notes:
  - Run only against targets you own or have permission to test (use Juice Shop / DVWA for labs).
  - This is a safe, educational PoC. Be cautious with POST tests on production sites.
"""
import argparse, json, time, sys
from urllib.parse import urlparse, urljoin, parse_qs, urlencode
import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

# === Configuration / payloads ===
XSS_PAYLOAD = "<script>alert(1)</script>"
SQLI_TESTS = ["' OR '1'='1", "\" OR \"1\"=\"1", "' OR '1'='1' -- "]
HEADERS_TO_CHECK = [
    "Content-Security-Policy",
    "X-Frame-Options",
    "Strict-Transport-Security",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]
TIMEOUT = 10
DEFAULT_WORDLIST = [
    "admin", "login", "dashboard", "uploads", "upload", "backup", "backup.zip", "backup.tar.gz",
    "robots.txt", "sitemap.xml", "api", "css", "js", "images", "img", "files", "downloads"
]

def fetch(url, session, method="GET", **kwargs):
    try:
        return session.request(method, url, timeout=TIMEOUT, allow_redirects=True, **kwargs)
    except requests.RequestException:
        return None

def header_checks(resp):
    findings = []
    if not resp:
        return findings
    for h in HEADERS_TO_CHECK:
        if h not in resp.headers:
            findings.append(f"Missing header: {h}")
    set_cookie = resp.headers.get("Set-Cookie", "")
    if set_cookie and "HttpOnly" not in set_cookie:
        findings.append("Cookie missing HttpOnly flag")
    if set_cookie and "Secure" not in set_cookie:
        findings.append("Cookie missing Secure flag")
    return findings

def fingerprint(resp):
    if not resp:
        return {}
    return {
        "server": resp.headers.get("Server"),
        "x-powered-by": resp.headers.get("X-Powered-By"),
        "status_code": getattr(resp, "status_code", None)
    }

def find_forms(html, base_url):
    forms = []
    if not html:
        return forms
    soup = BeautifulSoup(html, "html.parser")
    for form in soup.find_all("form"):
        action = form.get("action") or ""
        method = (form.get("method") or "get").lower()
        inputs = []
        for inp in form.find_all(["input", "textarea", "select"]):
            name = inp.get("name")
            itype = inp.get("type") or inp.name
            if name:
                inputs.append({"name": name, "type": itype})
        forms.append({"action": urljoin(base_url, action), "method": method, "inputs": inputs})
    return forms

def test_xss_in_url(target, session):
    parsed = urlparse(target)
    qs = parse_qs(parsed.query)
    results = []
    if not qs:
        return results
    for param in qs:
        inj = qs.copy()
        inj[param] = XSS_PAYLOAD
        new_q = urlencode({k: v for k, v in inj.items()}, doseq=True)
        test_url = parsed._replace(query=new_q).geturl()
        r = fetch(test_url, session)
        if r and XSS_PAYLOAD in r.text:
            results.append({"param": param, "url": test_url, "evidence": "payload reflected"})
    return results

def test_sqli_in_url(target, session):
    parsed = urlparse(target)
    qs = parse_qs(parsed.query)
    results = []
    if not qs:
        return results
    error_signatures = ["sql syntax","mysql","syntax error","unclosed quotation mark","odbc","pdoexception","sqlstate"]
    for param in qs:
        for payload in SQLI_TESTS:
            inj = qs.copy()
            inj[param] = payload
            new_q = urlencode({k: v for k, v in inj.items()}, doseq=True)
            test_url = parsed._replace(query=new_q).geturl()
            r = fetch(test_url, session)
            if not r:
                continue
            body = r.text.lower()
            if any(sig in body for sig in error_signatures):
                results.append({"param": param, "url": test_url, "evidence": "sql error in response"})
    return results

def submit_form_and_test_xss(form, session):
    findings = []
    action = form.get("action")
    method = form.get("method", "get").lower()
    data = {}
    for inp in form.get("inputs", []):
        field_type = inp.get("type", "")
        if field_type in ("text","search","email","textarea","password") or "text" in field_type:
            data[inp["name"]] = XSS_PAYLOAD
        else:
            data[inp["name"]] = "test"
    try:
        if method == "post":
            r = session.post(action, data=data, timeout=TIMEOUT)
        else:
            r = session.get(action, params=data, timeout=TIMEOUT)
        if r and XSS_PAYLOAD in r.text:
            findings.append({"form_action": action, "evidence": "payload reflected in response"})
    except requests.RequestException:
        pass
    return findings

def dir_bruteforce(base, session, wordlist, progress=True):
    found = []
    to_check = []
    for w in wordlist:
        to_check.append(urljoin(base, w))
        to_check.append(urljoin(base, w + "/"))
    iterable = tqdm(to_check, desc="Dir bruteforce", disable=not progress)
    for u in iterable:
        r = fetch(u, session)
        if r and r.status_code not in (404, 400, 403):
            found.append({"url": u, "status": r.status_code})
    return found

def scan_target(target, wordlist=None, progress=True, test_forms=True):
    session = requests.Session()
    session.headers.update({"User-Agent": "PoC-Scanner/0.1 (+edu@example.com)"})
    result = {
        "target": target,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "issues": [],
        "fingerprint": {},
        "forms": [],
        "dir_results": [],
    }

    r = fetch(target, session)
    if not r:
        result["issues"].append({"type": "unreachable", "detail": "Target did not respond or timed out"})
        return result

    # fingerprint and headers
    result["fingerprint"] = fingerprint(r)
    for hf in header_checks(r):
        result["issues"].append({"type": "header", "detail": hf})

    # forms
    result["forms"] = find_forms(r.text, target)
    if test_forms:
        for form in result["forms"]:
            findings = submit_form_and_test_xss(form, session)
            for f in findings:
                result["issues"].append({"type": "reflected-xss-post", "detail": f})

    # URL-based tests
    for v in test_xss_in_url(target, session):
        result["issues"].append({"type": "reflected-xss", "detail": v})
    for s in test_sqli_in_url(target, session):
        result["issues"].append({"type": "sqli", "detail": s})

    # directory brute-force
    wl = wordlist or DEFAULT_WORDLIST
    dirs = dir_bruteforce(target, session, wl, progress=progress)
    result["dir_results"] = dirs
    for d in dirs:
        result["issues"].append({"type": "discovery", "detail": f"Found {d['url']} (status {d['status']})"})

    return result

def main():
    parser = argparse.ArgumentParser(description="Simple Web App Vulnerability Scanner (PoC)")
    parser.add_argument("target", help="Target URL (include http/https). Example: https://example.com/page?param=1")
    parser.add_argument("--wordlist", help="Optional wordlist file for directory brute force")
    parser.add_argument("--no-progress", action="store_true", help="Disable progress bars")
    parser.add_argument("--out", help="Save JSON report to file")
    parser.add_argument("--no-form-tests", action="store_true", help="Disable automatic form submission (safer)")
    args = parser.parse_args()

    wl = None
    if args.wordlist:
        try:
            with open(args.wordlist, "r", encoding="utf-8") as f:
                wl = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Could not read wordlist: {e}", file=sys.stderr)
            wl = None

    res = scan_target(args.target, wordlist=wl, progress=not args.no_progress, test_forms=not args.no_form_tests)
    pretty = json.dumps(res, indent=2)
    print(pretty)
    if args.out:
        try:
            with open(args.out, "w", encoding="utf-8") as fo:
                fo.write(pretty)
            print(f"Saved report to {args.out}")
        except Exception as e:
            print(f"Could not save report: {e}", file=sys.stderr)

if __name__ == "__main__":
    import sys
    main()
