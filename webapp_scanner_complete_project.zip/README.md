Web Application Vulnerability Scanner - Project Package
Files included:
- scanner.py (PoC scanner)
- async_dirs.py (async directory enumerator)
- generate_report.py + report_template.html
- wordlists/common_dirs.txt and common_dirs_extended.txt
- reports/juice_scan.json (sample), and included PDFs if available
Run scanner: python scanner.py "http://localhost:3000" --wordlist wordlists/common_dirs.txt --out reports/juice_scan.json